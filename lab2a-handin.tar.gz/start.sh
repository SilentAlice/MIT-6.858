#!/bin/bash
./clean-env.sh ./zookld zook-exstack.conf
