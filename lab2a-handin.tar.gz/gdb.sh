#!/bin/bash
gdb -p $(pgrep zookd-exstack)
#gdb -p $(pgrep zookfs)
